setwd("C:/Users/Maleesha/OneDrive/Desktop/IT24101739")
data <- read.table("Data.txt",header=TRUE,sep=",")
fix(data)
attach(data)
names(data)<-c("X1","X2")
attach(data)
fix(data)
hist(X2,main = "Histogram for number of shareholders")
histogram <- hist(X2,main = "Histogram for number of shareholders",breaks = seq(130,270,length = 8),right = FALSE)
breaks <- round(histogram$breaks)
freq <- histogram$counts
mids <- histogram$mids
classes <- c()
for(i in 1:length(breaks)-1){
  classes[i]<-paste0("[",breaks[i],",",breaks[i + 1],")")
}
cbind(Classes = classes ,  Frequency = freq)
lines(mids, freq)
plot(mids, freq,type = 'l', main = "Frequency Polygon for Shareholders",xlab = "Shareholders",ylab = "Frequency",ylim = c(0,max(freq)))
cum.freq <- cumsum(freq)
new <- c()
for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
  }else{
    new[i]=cum.freq[i-1]
  }
}
plot(breaks,new,type = 'l',main = "Cumalative Frequency Polygon for Shareholders",xlab = "Shareholders",ylab = "Cumulative Frequency",ylim = c(0,max(cum.freq)))
cbind(Upper = breaks , cumFreq = new)

#Exersice

#Quesion 01
delivery_times <- read.table("Exercise - Lab 05.txt", header = FALSE)
colnames(delivery_times) <- c("Times")
delivery_times$Times <- as.numeric(as.character(delivery_times$Times))

#Quesion 02
breaks2 <- seq(20, 70, length.out = 10)

hist(delivery_times$Times,
     breaks = breaks2, 
     right = FALSE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Times (minutes)",
     ylab = "Frequency")

#Question 03
#Approximately symmetric distribution
#Single peak around 40-50 minutes (unimodal)
#Frequencies increase gradually to center
#Frequencies decrease gradually from center

#Question 04
freq_table2 <- table(cut(delivery_times$Times, breaks = breaks2, right = FALSE))
cum_freq2 <- cumsum(freq_table2)
midpoints2 <- (head(breaks2,-1) + tail(breaks2,-1)) / 2

plot(midpoints2, cum_freq2, type = "o",
     main = "Ogive for Delivery Times",
     xlab = "Delivery Times (minutes)",
     ylab = "Cumulative Frequency"
)